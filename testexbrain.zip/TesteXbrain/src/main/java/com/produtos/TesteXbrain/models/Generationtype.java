package com.produtos.TesteXbrain.models;

public class Generationtype {

}
