package com.produtos.TesteXbrain;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TesteXbrainApplication {

	public static void main(String[] args) {
		SpringApplication.run(TesteXbrainApplication.class, args);
	}

}
