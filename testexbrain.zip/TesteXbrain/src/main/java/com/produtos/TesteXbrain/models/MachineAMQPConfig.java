package com.produtos.TesteXbrain.models;

import org.springframework.amqp.rabbit.annotation.RabbitListener;

public class MachineAMQPConfig {

	public static final String QUEUE1 = null;
	public static final RabbitListener[] QUEUE = null;

}
